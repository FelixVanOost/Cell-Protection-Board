*****************************************************************************
Project Name
*****************************************************************************

Cell Protection Board - Rev. A

*****************************************************************************
Contact & Shipping Information
*****************************************************************************

Name:	 	Felix van Oost
Phone:		+1 (778) 919-2072
E-Mail:		felix.vanoost@live.com

Address:	2356 Main Mall, MCLD 112B
		RT228600
		Vancouver BC, V6T 1Z4
		Canada

*****************************************************************************
Fabrication Information
*****************************************************************************

Quantity:		7
Board Material:		FR4
Board Thickness:	0.062"
# of Layers:		2
Copper Weight:		1oz
Surface Finish:		Immersion Silver
Solder Mask:		Green
Silkscreen:		White
Board Dimensions:	55mm x 160mm

*****************************************************************************
Aditional Notes	 
*****************************************************************************

All vias to be plugged.

*****************************************************************************
Layers
*****************************************************************************
	
Board Outline:		Cell Protection Board.GM1
Top Overlay:		Cell Protection Board.GTO
Top Solder Mask:	Cell Protection Board.GTS
Top Layer:		Cell Protection Board.GTL
Bottom Solder Mask:	Cell Protection Board.GBS
Bottom Layer:		Cell Protection Board.GBL

NC Drill:		Cell Protection Board.txt	